﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Net;
using System.Text.RegularExpressions;
using System.IO;




namespace WinGetImageBing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        
        private void btnDownload_Click(object sender, EventArgs e)
        {

           


            using (WebClient client = new WebClient())
            {
                string htmlCode = client.DownloadString("http://www.bing.com/?cc=it");
               
                Int32 indice = htmlCode.IndexOf(@"/az/hprichbg/rb/");
                indice += 16;
                Int32 indice2 = htmlCode.IndexOf("'", indice);

                string testodaCercare = htmlCode.Substring(indice, indice2 - indice);
                string nomefile = testodaCercare.Substring(0, testodaCercare.IndexOf(".jpg") + 4);
                DownloadImage("http://www.bing.com/az/hprichbg/rb/" + nomefile);
                return;

                 
                
                 
            }


            

        }

        private void DownloadImage(string url)
        {
            if (txtPercorso.Text.Trim() == "")
            {
                MessageBox.Show("Selezionare un percorso e nome di file.");
                return;
            }
            HttpWebRequest httpWebRequest = (HttpWebRequest)HttpWebRequest.Create(url);

            using (HttpWebResponse httpWebReponse = (HttpWebResponse)httpWebRequest.GetResponse())
            {
                using (Stream stream = httpWebReponse.GetResponseStream())
                {
                     
                    Bitmap immagine = new Bitmap(Image.FromStream(stream));
                    immagine.Save(txtPercorso.Text);
                    MessageBox.Show("Download completato. Verifica in " + txtPercorso.Text  +"  il file immagine.");
                }
            }
        
        }

        private void BtnPercorso_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                
                txtPercorso.Text =  saveFileDialog1.FileName + ".jpg";

            }
        }
    }
}
