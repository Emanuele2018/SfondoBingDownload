﻿Imports System.Net
Imports System.Text.RegularExpressions
Imports System.IO

Public Class Form1

    Private Sub BtnPercorso_Click(sender As System.Object, e As System.EventArgs) Handles BtnPercorso.Click
        If saveFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            txtPercorso.Text = saveFileDialog1.FileName + ".jpg"
        End If

    End Sub

    Private Sub btnDownload_Click(sender As System.Object, e As System.EventArgs) Handles btnDownload.Click

        Using client As New WebClient()
            Dim htmlCode As String = client.DownloadString("http://www.bing.com/?cc=it")
            Dim indice As Int32 = htmlCode.IndexOf("/az/hprichbg/rb/")
            indice += 16
            Dim indice2 As Int32 = htmlCode.IndexOf("'", indice)
            Dim testoDaCercare As String = htmlCode.Substring(indice, indice2 - indice)
            Dim nomeFile As String = testoDaCercare.Substring(0, testoDaCercare.IndexOf(".jpg") + 4)

            DownloadImage("http://www.bing.com/az/hprichbg/rb/" + nomeFile)


        End Using

 
    End Sub


    Sub DownloadImage(url As String)
        If txtPercorso.Text.Trim() = "" Then
            MessageBox.Show("Selezionare un percorso e nome di file.")
            Exit Sub
        End If
        Dim httpWebRequest As HttpWebRequest = httpWebRequest.Create(url)
        Using httpwebresponse As HttpWebResponse = httpWebRequest.GetResponse()
            Using Stream As Stream = httpwebresponse.GetResponseStream()
                Dim immagine As New Bitmap(Image.FromStream(Stream))
                immagine.Save(txtPercorso.Text)
                MessageBox.Show("Download completato. Verifica in " + txtPercorso.Text + "  il file immagine.")
            End Using

        End Using



    End Sub


  
End Class
